// Data Access Tier - logic related to the data access tier

function processInfo(first_name, last_name, card_number, ticket_num, hour, movie_name, phone_number)
{
	var orderStr = stringify(first_name, last_name, card_number, ticket_num, hour, movie_name, phone_number);
	sessionStorage.setItem('order', orderStr);
}

function stringify(first_name, last_name, card_number, ticket_num, hour, movie_name, phone_number) {
	var firstnameStr = first_name;
	var lastNameStr = '™' + last_name;
	var cardStr = '™' + card_number;
	var ticketStr = '™' + ticket_num;
	var hourStr = '™' + hour;
	var movieStr = '™' + movie_name;
	var phoneStr = '™' + phone_number;
	var ordStr = firstnameStr + lastNameStr + cardStr + ticketStr + hourStr + movieStr + phoneStr;
	return ordStr;	
}

function getMovieName(id)
{
	var name =sessionStorage.getItem(id) 
	return name.split('™')[5];
}

function getMovieHour(id)
{
	var hour =sessionStorage.getItem(id) 
	return hour.split('™')[4];
}

function getTicketNum(id)
{
	return sessionStorage.getItem(id).split('™')[3];
}